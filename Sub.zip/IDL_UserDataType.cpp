// Don't modify this file as it will be overwritten.
//
#include "IDL_UserDataType.h"

UserDataType::UserDataType(const UserDataType &IDL_s){
  nm = IDL_s.nm;
  b = IDL_s.b;
  str = IDL_s.str;
}

UserDataType& UserDataType::operator= (const UserDataType &IDL_s){
  if (this == &IDL_s) return *this;
  nm = IDL_s.nm;
  b = IDL_s.b;
  str = IDL_s.str;
  return *this;
}

void UserDataType::Marshal(CDR *cdr) const {
  cdr->PutShort(nm);
  cdr->PutShort(b);
  cdr->PutString(str);
}

void UserDataType::UnMarshal(CDR *cdr){
  cdr->GetShort(nm);
  cdr->GetShort(b);
  {
    char *IDL_str;
    cdr->GetString(IDL_str);
    if(str != NULL )
    {
        delete str;
        str = NULL;
    }
    str = IDL_str;
  }
}

demo::demo(const demo &IDL_s){
  nb = IDL_s.nb;
  y = IDL_s.y;
  str = IDL_s.str;
}

demo& demo::operator= (const demo &IDL_s){
  if (this == &IDL_s) return *this;
  nb = IDL_s.nb;
  y = IDL_s.y;
  str = IDL_s.str;
  return *this;
}

void demo::Marshal(CDR *cdr) const {
  cdr->PutShort(nb);
  cdr->PutShort(y);
  cdr->PutString(str);
}

void demo::UnMarshal(CDR *cdr){
  cdr->GetShort(nb);
  cdr->GetShort(y);
  {
    char *IDL_str;
    cdr->GetString(IDL_str);
    if(str != NULL )
    {
        delete str;
        str = NULL;
    }
    str = IDL_str;
  }
}

