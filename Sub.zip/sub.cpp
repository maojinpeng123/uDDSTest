/**********************************************************
*****************订阅端程序subscriber.cpp*******************
***********************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <unistd.h>
#include <csignal>
#include <ctime>
#include <iostream>
#include<atomic>
#include <openssl/md5.h>
#include <chrono> 
/* IDL_TypeSupport.h中包含所有依赖的头文件 */
#include "IDL_TypeSupport.h"
//控制执行哪个测试用例
#define WhichExample 1

static void MaoMrMD5(const std::string& input, std::string& output)
{

	std::string result;
	std::string data((const size_t)16, '\0');
	MD5_CTX md5;
	MD5_Init(&md5);
	MD5_Update(&md5, input.c_str(), input.size());
	MD5_Final((unsigned char*)data.c_str(), &md5);
	char temp[3]{};
	for (size_t i = 0; i < data.size(); i++)
	{
		memset(temp, 0, sizeof(temp));
		snprintf(temp, sizeof(temp), "%02x", data[i] & 0xFF);
		result += temp;
	}
	output = result;

}
static int publisher_shutdown(DomainParticipant* participant)
{
	ReturnCode_t retcode;
	int status = 0;

	if (participant != NULL) {
		retcode = participant->delete_contained_entities();
		if (retcode != RETCODE_OK) {
			fprintf(stderr, "delete_contained_entities error %d\n", retcode);
			status = -1;
		}

		retcode = DomainParticipantFactory::get_instance()->delete_participant(participant);
		if (retcode != RETCODE_OK) {
			fprintf(stderr, "delete_participant error %d\n", retcode);
			status = -1;
		}
	}

	return status;
}
/* UserDataTypeListener继承于DataReaderListener，
   需要重写其继承过来的方法on_data_available()，在其中进行数据监听读取操作 */
class UserDataTypeListener : public DataReaderListener {
public:
	UserDataTypeListener() :m_TimerId(0)
	{ /*if (WhichExample == 3)initSender();*/ };
	~UserDataTypeListener();
	virtual void on_data_available(DataReader* reader);
	void StartTimer(int interval);//单位秒
	void StopTimer();
	// 获取当前时间戳（微秒）
	long long getCurrentTimestamp();
	// 定时器回调函数
	static void timerHandler(int signum);
	static long long m_TimerDuration;//秒
	static std::atomic<long long> m_RecvedPacketCount;
	static std::atomic<long long> m_ShouldRecvedPacketCount;
	static std::atomic<long long> m_TotalDataSize;//bit
	timer_t m_TimerId;
	string m_MD5Str;
	static std::atomic<long long> m_StartTime;
	static std::atomic<long long> m_EndTime;
	static std::atomic<long long> m_CircleCount;
	//发送数据者创建
	int initSender(/*DomainParticipant* participant, Topic* topic*/);
	DomainParticipant* participant = NULL;
	Publisher* publisher = NULL;
	Topic* topic = NULL;
	DataWriter* writer = NULL;
	UserDataTypeDataWriter* UserDataType_writer = NULL;
	UserDataType* instance = NULL;
	ReturnCode_t retcode;
	InstanceHandle_t instance_handle = HANDLE_NIL;
	const char* type_name = NULL;
	int count = 0;
};
long long UserDataTypeListener::m_TimerDuration = 0;
std::atomic<long long> UserDataTypeListener::m_TotalDataSize(0);
std::atomic<long long> UserDataTypeListener::m_RecvedPacketCount(0);
std::atomic<long long> UserDataTypeListener::m_ShouldRecvedPacketCount(0);
std::atomic<long long> UserDataTypeListener::m_StartTime(0);
std::atomic<long long> UserDataTypeListener::m_EndTime(0);
std::atomic<long long> UserDataTypeListener::m_CircleCount(0);
UserDataTypeListener::~UserDataTypeListener()
{
	/* 8. 删除数据样本 */
	retcode = UserDataTypeTypeSupport::delete_data(instance);
	if (retcode != RETCODE_OK) {
		fprintf(stderr, "UserDataTypeTypeSupport::delete_data error %d\n", retcode);
	}

	/* 9. 删除所有发布者实例 */
	publisher_shutdown(participant);
	
	StopTimer();
}

/* 重写继承过来的方法on_data_available()，在其中进行数据监听读取操作 */
void UserDataTypeListener::on_data_available(DataReader* reader)
{
	UserDataTypeDataReader* UserDataType_reader = NULL;
	UserDataTypeSeq data_seq;
	SampleInfoSeq info_seq;
	ReturnCode_t retcode;
	int i;

	/* 利用reader，创建一个读取UserDataType类型的UserDataType_reader*/
	UserDataType_reader = UserDataTypeDataReader::narrow(reader);
	if (UserDataType_reader == NULL) {
		fprintf(stderr, "DataReader narrow error\n");
		return;
	}

	/* 获取数据，存放至data_seq，data_seq是一个队列 */
	retcode = UserDataType_reader->read(
		data_seq, info_seq, 10, 0, 0, 0);

	if (retcode == RETCODE_NO_DATA) {
		return;
	}
	else if (retcode != RETCODE_OK) {
		fprintf(stderr, "take error %d\n", retcode);
		return;
	}

		/* 打印数据 */
	/* 建议1：避免在此进行复杂数据处理 */
	/* 建议2：将数据传送到其他数据处理线程中进行处理 *
	/* 建议3：假如数据结构中有string类型，用完后需手动释放 */
		for (i = 0; i < data_seq.length(); ++i) {
			
			if (WhichExample == 1) {
				UserDataTypeTypeSupport::print_data(&data_seq[i]);
				if (m_MD5Str.size()) {
					string md5Out, recvmsg,md5recv;
					MaoMrMD5(m_MD5Str, md5Out);
					recvmsg = data_seq[i].str;
					md5recv = recvmsg.substr(recvmsg.size() - 32, 32);
					if (md5Out != md5recv) {//如果MD5不一致
						std::cout << "the sender's MD5 and self MD5 Values are inconsistent"<<" the recved msg"<< recvmsg.substr(0,recvmsg.size() - 32)<< std::endl;
					}
					else {
						std::cout <<"check MD5 success! the recved msg:" << recvmsg.substr(0, recvmsg.size() - 32) << std::endl;
					}
				}
				else {
					std::cout << "You must input the MD5 str!" << std::endl;
				}

			}
			else if (WhichExample == 2) {
				UserDataTypeListener::m_RecvedPacketCount.fetch_add(1);
				UserDataTypeListener::m_TotalDataSize.fetch_add((data_seq[i].StructSize() - sizeof(char*)) * 8);
				UserDataTypeListener::m_ShouldRecvedPacketCount.store((long long)(0xFFFF & data_seq[i].nm) + ((long long)(0xFFFF & data_seq[i].b) * 65535));//nm表示已发送包的数量，b表示总共溢出了几个short。
				//UserDataTypeTypeSupport::print_data(&data_seq[i]);
				//std::cout << "recv one packet !" << std::endl;
			}
			else if (WhichExample == 3) {//只要发送方一开始只发一个包然后等待接收方返回消息后才进行后续操作，这样就保证了不会有多个包同时被收到
				UserDataTypeTypeSupport::print_data(&data_seq[i]);
				static bool isFirst = false;
				m_CircleCount.fetch_add(1);
				if (isFirst == false) {//第一次
					isFirst = true;
					m_StartTime.store(getCurrentTimestamp());
				}
				else m_EndTime.store(getCurrentTimestamp());//后续
				//发送数据给对方
				/* 6. 创建一个数据样本 */
			    /* 建议：该数据为new出来的，使用后用户需要调用delete_data进行释放内存*/
				instance = UserDataTypeTypeSupport::create_data();
				if (instance == NULL) {
					fprintf(stderr, "UserDataTypeTypeSupport::create_data error\n");
					publisher_shutdown(participant);
					return;
				}
				*instance=data_seq[i];
				//发送接收到的数据过去
				retcode = UserDataType_writer->write(*instance, instance_handle);
				if (retcode != RETCODE_OK) {
					fprintf(stderr, "write error %d\n", retcode);
				}
				else
					fprintf(stderr, "%d : write  successfully . . \n", count);
			}

		}
	
	
}
void UserDataTypeListener::StartTimer(int interval)
{
	// 注册信号处理函数
	struct sigaction sa {};
	sa.sa_handler = &UserDataTypeListener::timerHandler;
	sigaction(SIGALRM, &sa, nullptr);

	std::cout << " StartTimer !" << std::endl;
	// 创建定时器

	struct sigevent sev {};
	sev.sigev_notify = SIGEV_SIGNAL;
	sev.sigev_signo = SIGALRM;
	sev.sigev_value.sival_ptr = &m_TimerId;
	if (timer_create(CLOCK_REALTIME, &sev, &m_TimerId) == -1) {
		std::cerr << "Failed to create timer!" << std::endl;
		return;
	}

	// 设置定时器间隔
	struct itimerspec its {};
	its.it_value.tv_sec = 1;  // 第一次触发时间（1 秒后）
	its.it_value.tv_nsec = 0;
	its.it_interval.tv_sec = interval;  // 后续触发间隔（1 秒）
	its.it_interval.tv_nsec = 0;
	if (timer_settime(m_TimerId, 0, &its, nullptr) == -1) {
		std::cerr << "Failed to set timer!" << std::endl;
		return;
	}

}

void UserDataTypeListener::StopTimer()
{
	// 删除定时器
	timer_delete(m_TimerId);
	m_TimerDuration = 0;
	m_TotalDataSize = 0;
	m_RecvedPacketCount = 0;
	m_ShouldRecvedPacketCount = 0;
}

long long UserDataTypeListener::getCurrentTimestamp()
{
	auto now = std::chrono::system_clock::now();  // 获取当前时间点
	auto duration = now.time_since_epoch();  // 获取时间间隔
	return std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
}

void UserDataTypeListener::timerHandler(int signum)
{
	//std::cout << "TimerHandler trigger!" << std::endl;
	if (WhichExample == 2) {
		m_TimerDuration++;
		auto ret = m_TotalDataSize.load() / m_TimerDuration;

		auto a = UserDataTypeListener::m_RecvedPacketCount.load();
		auto b = UserDataTypeListener::m_ShouldRecvedPacketCount.load();
		double ret1 = ((double)(b - a) / b) * 100;
		//吞吐量
		std::cout << "The Throughput :" << ret << "Mbps" << std::endl;
		//接收端打印丢包率:
		std::cout << "The Packet loss rate :" << ret1 << "%" << std::endl;
		//std::cout << "The recved :" << a << " The should recved:"<<b << std::endl;
	}
	else if (WhichExample == 3) {
		if (m_CircleCount.load() != 0) {
			auto ret = (m_EndTime.load() - m_StartTime.load()) / m_CircleCount.load() / 2;
			//延迟
			std::cout << "The Delay :" << ret << " us" << std::endl;
		}
		
	}

}

int UserDataTypeListener::initSender(/*DomainParticipant* participant, Topic* topic*/)
{
	/* 1. 创建一个participant，可以在此处定制participant的QoS */
	/* 建议1：在程序启动后优先创建participant，进行资源初始化*/
	/* 建议2：相同的domainId只创建一次participant，重复创建会占用大量资源 */
	participant = DomainParticipantFactory::get_instance()->create_participant(
		1, PARTICIPANT_QOS_DEFAULT/* participant默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (participant == NULL) {
		fprintf(stderr, "create_participant error\n");
		publisher_shutdown(participant);
		return -1;
	}
	/*this->participant = participant;
	this->topic = topic;*/
	/* 2. 创建一个publisher，可以在创建publisher的同时定制其QoS  */
	/* 建议1：在程序启动后优先创建publisher */
	/* 建议2：一个participant下创建一个publisher即可，无需重复创建 */
	publisher = participant->create_publisher(
		PUBLISHER_QOS_DEFAULT /* 默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (publisher == NULL) {
		fprintf(stderr, "create_publisher error\n");
		publisher_shutdown(participant);
		return -1;
	}

	/* 3. 在创建主题之前注册数据类型 */
	/* 建议1：在程序启动后优先进行注册 */
	/* 建议2：一个数据类型注册一次即可 */
	type_name = UserDataTypeTypeSupport::get_type_name();
	retcode = UserDataTypeTypeSupport::register_type(
		participant, type_name);
	if (retcode != RETCODE_OK) {
		fprintf(stderr, "register_type error %d\n", retcode);
		publisher_shutdown(participant);
		return -1;
	}

	/* 4. 创建主题，并定制主题的QoS  */
	/* 建议1：在程序启动后优先创建Topic */
	/* 建议2：一种主题名创建一次即可，无需重复创建 */
	topic = participant->create_topic(
		"Example UserDataType1"/* 主题名 */,
		type_name /* 类型名 */, TOPIC_QOS_DEFAULT/* 默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (topic == NULL) {
		fprintf(stderr, "create_topic error1\n");
		publisher_shutdown(participant);
		return -1;
	}

	/* 5. 创建datawriter，并定制datawriter的QoS  */
	/* 建议1：在程序启动后优先创建datawriter */
	/* 建议2：创建一次即可，无需重复创建 */
	/* 建议3：在程序退出时再进行释放 */
	/* 建议4：避免打算发送数据时创建datawriter，发送数据后删除，该做法消耗资源，影响性能 */
	writer = publisher->create_datawriter(
		topic, DATAWRITER_QOS_DEFAULT/* 默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (writer == NULL) {
		fprintf(stderr, "create_datawriter error\n");
		publisher_shutdown(participant);
		return -1;
	}
	UserDataType_writer = UserDataTypeDataWriter::narrow(writer);
	if (UserDataType_writer == NULL) {
		fprintf(stderr, "DataWriter narrow error\n");
		publisher_shutdown(participant);
		return -1;
	}
}

/* 删除所有实体 */
static int subscriber_shutdown(
	DomainParticipant* participant)
{
	ReturnCode_t retcode;
	int status = 0;

	if (participant != NULL) {
		retcode = participant->delete_contained_entities();
		if (retcode != RETCODE_OK) {
			fprintf(stderr, "delete_contained_entities error %d\n", retcode);
			status = -1;
		}

		retcode = DomainParticipantFactory::get_instance()->delete_participant(participant);
		if (retcode != RETCODE_OK) {
			fprintf(stderr, "delete_participant error %d\n", retcode);
			status = -1;
		}
	}
	return status;
}

/* 订阅者函数 */
extern "C" int subscriber_main(int domainId, int sample_count)
{
	DomainParticipant* participant = NULL;
	Subscriber* subscriber = NULL;
	Topic* topic = NULL;
	UserDataTypeListener* reader_listener = NULL;
	DataReader* reader = NULL;
	ReturnCode_t retcode;
	const char* type_name = NULL;
	int count = 0;
	int status = 0;

	/* 1. 创建一个participant，可以在此处定制participant的QoS */
	/* 建议1：在程序启动后优先创建participant，进行资源初始化*/
	/* 建议2：相同的domainId只创建一次participant，重复创建会占用大量资源 */
	participant = DomainParticipantFactory::get_instance()->create_participant(
		domainId, PARTICIPANT_QOS_DEFAULT/* participant默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (participant == NULL) {
		fprintf(stderr, "create_participant error\n");
		subscriber_shutdown(participant);
		return -1;
	}

	/* 2. 创建一个subscriber，可以在创建subscriber的同时定制其QoS  */
	/* 建议1：在程序启动后优先创建subscriber*/
	/* 建议2：一个participant下创建一个subscriber即可，无需重复创建 */
	subscriber = participant->create_subscriber(
		SUBSCRIBER_QOS_DEFAULT/* 默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (subscriber == NULL) {
		fprintf(stderr, "create_subscriber error\n");
		subscriber_shutdown(participant);
		return -1;
	}

	/* 3. 在创建主题之前注册数据类型 */
	/* 建议1：在程序启动后优先进行注册 */
	/* 建议2：一个数据类型注册一次即可 */
	type_name = UserDataTypeTypeSupport::get_type_name();
	retcode = UserDataTypeTypeSupport::register_type(
		participant, type_name);
	if (retcode != RETCODE_OK) {
		fprintf(stderr, "register_type error %d\n", retcode);
		subscriber_shutdown(participant);
		return -1;
	}

	/* 4. 创建主题，并定制主题的QoS  */
	/* 建议1：在程序启动后优先创建Topic */
	/* 建议2：一种主题名创建一次即可，无需重复创建 */
	topic = participant->create_topic(
		"Example UserDataType"/* 主题名，应与发布者主题名一致 */,
		type_name, TOPIC_QOS_DEFAULT/* 默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (topic == NULL) {
		fprintf(stderr, "create_topic error\n");
		subscriber_shutdown(participant);
		return -1;
	}

	/* 5. 创建一个监听器 */
	reader_listener = new UserDataTypeListener();

	reader_listener->StartTimer(1);
	/* 6. 创建datareader，并定制datareader的QoS */
	/* 建议1：在程序启动后优先创建datareader*/
	/* 建议2：创建一次即可，无需重复创建 */
	/* 建议3：在程序退出时再进行释放 */
	/* 建议4：避免打算接收数据时创建datareader，接收数据后删除，该做法消耗资源，影响性能 */
	reader = subscriber->create_datareader(
		topic, DATAREADER_QOS_DEFAULT/* 默认QoS */,
		reader_listener/* listener */, STATUS_MASK_ALL);
	if (reader == NULL) {
		fprintf(stderr, "create_datareader error\n");
		subscriber_shutdown(participant);
		delete reader_listener;
		return -1;
	}

	/* 7. 主循环 ，监听器会默认调用on_data_available()监听数据 */
	for (count = 0; (sample_count == 0) || (count < sample_count); ++count) {
		//保持进程一直运行

	}


	/* 8. 删除所有实体和监听器 */
	status = subscriber_shutdown(participant);
	delete reader_listener;

	return status;
}

int test(int domainId, int sample_count,const string& MD5Str) {
	DomainParticipant* participant = NULL;
	Subscriber* subscriber = NULL;
	Topic* topic = NULL;
	UserDataTypeListener* reader_listener = NULL;
	DataReader* reader = NULL;
	ReturnCode_t retcode;
	const char* type_name = NULL;
	int count = 0;
	int status = 0;

	/* 1. 创建一个participant，可以在此处定制participant的QoS */
	/* 建议1：在程序启动后优先创建participant，进行资源初始化*/
	/* 建议2：相同的domainId只创建一次participant，重复创建会占用大量资源 */
	participant = DomainParticipantFactory::get_instance()->create_participant(
		domainId, PARTICIPANT_QOS_DEFAULT/* participant默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (participant == NULL) {
		fprintf(stderr, "create_participant error\n");
		subscriber_shutdown(participant);
		return -1;
	}
	/* 2. 创建一个subscriber，可以在创建subscriber的同时定制其QoS  */
	/* 建议1：在程序启动后优先创建subscriber*/
	/* 建议2：一个participant下创建一个subscriber即可，无需重复创建 */
	subscriber = participant->create_subscriber(
		SUBSCRIBER_QOS_DEFAULT/* 默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (subscriber == NULL) {
		fprintf(stderr, "create_subscriber error\n");
		subscriber_shutdown(participant);
		return -1;
	}

	/* 3. 在创建主题之前注册数据类型 */
	/* 建议1：在程序启动后优先进行注册 */
	/* 建议2：一个数据类型注册一次即可 */
	type_name = UserDataTypeTypeSupport::get_type_name();
	retcode = UserDataTypeTypeSupport::register_type(
		participant, type_name);
	if (retcode != RETCODE_OK) {
		fprintf(stderr, "register_type error %d\n", retcode);
		subscriber_shutdown(participant);
		return -1;
	}

	/* 4. 创建主题，并定制主题的QoS  */
	/* 建议1：在程序启动后优先创建Topic */
	/* 建议2：一种主题名创建一次即可，无需重复创建 */
	topic = participant->create_topic(
		"Example UserDataType"/* 主题名，应与发布者主题名一致 */,
		type_name, TOPIC_QOS_DEFAULT/* 默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (topic == NULL) {
		fprintf(stderr, "create_topic error\n");
		subscriber_shutdown(participant);
		return -1;
	}

	/* 5. 创建一个监听器 */
	reader_listener = new UserDataTypeListener();
	if (WhichExample == 1)
	reader_listener->m_MD5Str=MD5Str;
	else if (WhichExample == 3) {
		reader_listener->initSender(/*participant, topic*/);
	}
	
	reader_listener->StartTimer(1);
	/* 6. 创建datareader，并定制datareader的QoS */
	/* 建议1：在程序启动后优先创建datareader*/
	/* 建议2：创建一次即可，无需重复创建 */
	/* 建议3：在程序退出时再进行释放 */
	/* 建议4：避免打算接收数据时创建datareader，接收数据后删除，该做法消耗资源，影响性能 */
	reader = subscriber->create_datareader(
		topic, DATAREADER_QOS_DEFAULT/* 默认QoS */,
		reader_listener/* listener */, STATUS_MASK_ALL);
	if (reader == NULL) {
		fprintf(stderr, "create_datareader error\n");
		subscriber_shutdown(participant);
		delete reader_listener;
		return -1;
	}

	/* 7. 主循环 ，监听器会默认调用on_data_available()监听数据 */
	for (count = 0; (sample_count == 0) || (count < sample_count); ++count) {
		//保持进程一直运行

	}


	/* 8. 删除所有实体和监听器 */
	status = subscriber_shutdown(participant);
	delete reader_listener;

	return status;
}

int main(int argc, char* argv[])
{
	int domain_id = 0;
	int sample_count = 0; /* 无限循环 */
	string MD5Str;
	if (argc >= 2) {
		domain_id = atoi(argv[1]);/* 发送至域domain_id */
	}
	if (argc >= 3) {
		sample_count = atoi(argv[2]);/* 发送sample_count次 */
		sample_count = 0;//接收端不主动设置循环次数，否则程序不可控
	}
	if(WhichExample==1)
	if (argc >= 4) {
		MD5Str = argv[3];
		std::cout << "the MD5 string is assigned" << std::endl;
	}
	return test(domain_id,sample_count,MD5Str)/*subscriber_main(domain_id, sample_count)*/;
}

