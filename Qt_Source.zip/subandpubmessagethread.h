﻿#ifndef CSUBANDPUBMESSAGETHREAD_H
#define CSUBANDPUBMESSAGETHREAD_H

#include <QThread>
#include <QObject>
#include<atomic>
#include<QTcpSocket>
//#include "IDL_TypeSupport.h"
//class DomainParticipant;
//class DataReader;
/* UserDataTypeListener继承于DataReaderListener，
   需要重写其继承过来的方法on_data_available()，在其中进行数据监听读取操作 */
//class UserDataTypeListener : public DataReaderListener {
//public:
//    /* 重写继承过来的方法on_data_available()，在其中进行数据监听读取操作 */
//    virtual void on_data_available(DataReader* reader);

//};

class CSubAndPubMessageThread : public QThread
{
    Q_OBJECT
public:
    explicit CSubAndPubMessageThread(QObject *parent = nullptr);
    ~CSubAndPubMessageThread();
    bool haTaskRunning();
    void stopCurTask();
signals:
    void endPubOrSubTask(int op);
protected:
    void run()override;
public slots:
    void pubTheMessage(const QString& msg);
    void subTheTopic(const QString& topic);
    void onReadyData();
    void threadInit();
private:
//    int publisher_shutdown(DomainParticipant *participant);

//    /* 发布者函数 */
//    /*extern "C" */int publisher_main(int domainId, int sample_count,const QString& msg);

//    /* 删除所有实体 */
//    int subscriber_shutdown(DomainParticipant *participant);

//    /* 订阅者函数 */
//    /*extern "C" */int subscriber_main(int domainId, int sample_count,const QString& msg);

private:
    std::atomic<bool> m_hasTaskRunning;
    QTcpSocket* m_tcpSocket;
};

#endif // CSUBANDPUBMESSAGETHREAD_H
