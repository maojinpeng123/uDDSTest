﻿#include "mywidget.h"
#include<QPainter>
CMyWidget::CMyWidget(QWidget *parent)
    : QWidget{parent}
{

}

void CMyWidget::paintEvent(QPaintEvent *e)
{
    QPainter painter(this);
    QPixmap pixmap(":/images/image.png");
    painter.drawPixmap(0, 0, width(), height(), pixmap);
}
