﻿#ifndef CMYWIDGET_H
#define CMYWIDGET_H

#include <QWidget>

class CMyWidget : public QWidget
{
    Q_OBJECT
public:
    explicit CMyWidget(QWidget *parent = nullptr);
protected:
    void paintEvent(QPaintEvent* e)override;
signals:

};

#endif // CMYWIDGET_H
