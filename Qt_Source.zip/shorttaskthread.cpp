﻿#include "shorttaskthread.h"

CShortTaskThread::CShortTaskThread()
{

}

void CShortTaskThread::run()
{
    emit finished(m_TaskCallback());
}
