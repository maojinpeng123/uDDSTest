﻿#ifndef CSHORTTASKTHREAD_H
#define CSHORTTASKTHREAD_H

#include <QRunnable>
#include <QObject>
#include<iostream>
#include<functional>

class CShortTaskThread : public QObject, public QRunnable
{
    Q_OBJECT
public:
    CShortTaskThread();
    //注意！传递的任务函数返回值必须是void类型，参数类型也必须和任务函数一一对应
    template<class Func, class ...Args>
    void setTaskFunction(Func&& func, Args...args){
        m_TaskCallback=std::bind(func,args...);
    }

signals:
    void finished(int op);
protected:
    void run()override;
private:
    std::function<int()> m_TaskCallback;
};

#endif // CSHORTTASKTHREAD_H
