﻿#ifndef CMYWORKTHREAD_H
#define CMYWORKTHREAD_H

#include <QThread>
#include <QObject>
#define MYSQL_ADDR  "127.0.0.1"// MySQL 服务器地址
#define MYSQL_PORT 3306//设置MYSQL端口
#define MYSQL_DBNAME  "mysql"// 数据库名称
#define MYSQL_USERNAME  "root"// 用户名
#define MYSQL_USERPASSWORD  "123456"// 密码
class QSqlDatabase;
class QSqlQuery;
class QTableWidgetItem;
class CMyWorkThread : public QThread
{
    Q_OBJECT
public:
    explicit CMyWorkThread(QObject *parent = nullptr);
    ~CMyWorkThread();
public slots:
    void initDB();
    void createDBTableData();
    void dbTableSort();
    void reserveDBTableSingleRow();
    void sendStringTask(QString str);
signals:
    void dbQueryError(int op,const QString& errorStr);
    void insertDBDataToTable_S(int op,int row,int column,QTableWidgetItem* item);
    void insertBDFinished(int op);
    void clearDBDataTable();
    void endSendStringTask();
protected:
    void run()override;
private:
    void insertDBDataToTable(int op,QSqlQuery* q);

private:
    QSqlDatabase* m_db;
};

#endif // CMYWORKTHREAD_H
