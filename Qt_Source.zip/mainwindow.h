﻿#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

class QFile;
class QSqlDatabase;
class QSqlQuery;
class CMyWorkThread;
class QTableWidgetItem;
class CSubAndPubMessageThread;
QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
public:
    //初始化数据库MySQL
    void initDB();

signals:
    void createDBTableData();
    void dbTableSort();
    void reserveDBTableSingleRow();
    void initDB_S();
    void pubStringTask(const QString& str);
    void subTopicTask(const QString& str);
private slots:
    void clearDBDataTable();
    int insertDBDataToTable(int op,int row,int column,QTableWidgetItem* item);
    void insertBDFinishedCb(int op);
    void TableReverseOrder();
    void toolbarOperate1();
    void toolbarOperate2();
    void toolbarOperate3();
    void toolbarOperate4();
    void toolbarOperate5();
    void openNewPage();
    void startWriteFileTask();
    void startPubString();
    void startSubTopic();
    void endPubOrSubTask(int op);
    void setValueToZero();
    void reserveSingle();
    void dbQueryError(int op,const QString& errorStr);
private:
    //初始化树model
    void initTreeModel();
    //初始化8行5列表格
    void initTable1();
    //初始化菜单工具状态栏
    void initTileBarTools();

    void initSendStringEvent();
    int writeFileTask(QFile* file);


private:
    CMyWorkThread* m_workThread;
    CSubAndPubMessageThread* m_messageThread;
    QFile* m_file;
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
