﻿#include "myworkthread.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include<QDebug>
#include<QRandomGenerator>
#include<QTableWidgetItem>
CMyWorkThread::CMyWorkThread(QObject *parent)
    : QThread{parent}
    ,m_db(0)
{
    this->moveToThread(this);
}

CMyWorkThread::~CMyWorkThread()
{
    quit();
    wait();
    if(m_db)delete m_db;
}

void CMyWorkThread::run()
{
    exec();
}

void CMyWorkThread::insertDBDataToTable(int op, QSqlQuery *q)
{
    switch (op) {
    case 0:
    {
// 插入 1000 行数据
    QSqlQuery query;
    for (int i = 0; i < 1000; ++i) {
        int random1 = QRandomGenerator::global()->bounded(3000);
        int random2 = QRandomGenerator::global()->bounded(3000);
        int random3 = QRandomGenerator::global()->bounded(3000);

        query.prepare(u8"INSERT INTO 数据库表1(随机数1,随机数2,随机数3) VALUES(?,?,?)");
        query.bindValue(0, random1);
        query.bindValue(1, random2);
        query.bindValue(2, random3);

        if (!query.exec()) {
            emit dbQueryError(5,query.lastError().text());
            //QMessageBox::critical(this, u8"错误", "插入数据失败: " + query.lastError().text());//关于UI操作包含创建新窗口时只能在主线程操作
            return;
        }
        emit insertDBDataToTable_S(op,i,0,new QTableWidgetItem(QString::number(i)));
        emit insertDBDataToTable_S(op,i,1,new QTableWidgetItem(QString::number(random1)));
        emit insertDBDataToTable_S(op,i,2,new QTableWidgetItem(QString::number(random2)));
        emit insertDBDataToTable_S(op,i,3,new QTableWidgetItem(QString::number(random3)));
        qDebug()<<"插入第"<<i+1<<"次";
    }

    }
        break;
    case 1:
    {
    // 插入数据到表格
    int row = 0;
    while (q->next()) {
        int id = q->value(u8"序号").toInt();
                 int random1 = q->value(u8"随机数1").toInt();
              int random2 = q->value(u8"随机数2").toInt();
              int random3 = q->value(u8"随机数3").toInt();

              emit insertDBDataToTable_S(op,row,0,new QTableWidgetItem(QString::number(id)));
              emit insertDBDataToTable_S(op,row,1,new QTableWidgetItem(QString::number(random1)));
              emit insertDBDataToTable_S(op,row,2,new QTableWidgetItem(QString::number(random2)));
              emit insertDBDataToTable_S(op,row,3,new QTableWidgetItem(QString::number(random3)));

        row++;
    }
    delete q;
    }
        break;
    case 2:
    {
    // 插入过滤后的数据到表格
    int row = 0;
    while (q->next()) {
        int id = q->value("序号").toInt();
        int random1 = q->value("随机数1").toInt();
        int random2 = q->value("随机数2").toInt();
        int random3 = q->value("随机数3").toInt();

        emit insertDBDataToTable_S(op,row,0,new QTableWidgetItem(QString::number(id)));
        emit insertDBDataToTable_S(op,row,1,new QTableWidgetItem(QString::number(random1)));
        emit insertDBDataToTable_S(op,row,2,new QTableWidgetItem(QString::number(random2)));
        emit insertDBDataToTable_S(op,row,3,new QTableWidgetItem(QString::number(random3)));
        row++;
    }

    // 删除“随机数3”列为偶数的行
    if (!q->exec("DELETE FROM 数据库表1 WHERE 随机数3 % 2 = 0")) {
        emit dbQueryError(6,q->lastError().text());
        //QMessageBox::critical(this, "错误", "删除失败: " + q->lastError().text());
        delete q;
        return ;
    }

    delete q;
    }
        break;
    default:
        break;
    }
    emit insertBDFinished(op);
    return ;
}

void CMyWorkThread::initDB()
{

if (QSqlDatabase::isDriverAvailable("QMYSQL")) {
    qDebug() << u8"QMYSQL 驱动可用";

} else {
    qDebug() << u8"QMYSQL 驱动不可用";

}


m_db=new QSqlDatabase;
 // 打开 MySQL 数据库
*m_db=QSqlDatabase::addDatabase(u8"QMYSQL");
m_db->setHostName(MYSQL_ADDR); // MySQL 服务器地址
m_db->setPort(MYSQL_PORT);//设置MYSQL端口
m_db->setDatabaseName(MYSQL_DBNAME); // 数据库名称
m_db->setUserName(MYSQL_USERNAME); // 用户名
m_db->setPassword(MYSQL_USERPASSWORD); // 密码

    if (!m_db->open()) {
    emit dbQueryError(1,m_db->lastError().text());
    qDebug()<<"无法打开数据库";
    //QMessageBox::critical(this, u8"错误", "无法打开数据库:" + m_db->lastError().text());
        return;
    }

}

void CMyWorkThread::createDBTableData()
{

    // 创建表（如果不存在）
    qDebug()<<"createDBTableData";
    QSqlQuery* query=new QSqlQuery(*m_db);

    if (!query->exec(u8"CREATE TABLE IF NOT EXISTS 数据库表1("
                    u8"序号 INT PRIMARY KEY AUTO_INCREMENT, "
                    u8"随机数1 INT, "
                    u8"随机数2 INT, "
                    u8"随机数3 INT)"
                    u8"CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci")) {
        emit dbQueryError(2,query->lastError().text());

      return;
    }

    // 更新UI表格
    emit clearDBDataTable();
    insertDBDataToTable(0,query);

}

void CMyWorkThread::dbTableSort()
{
// 按照“随机数2”列从大到小排序
    qDebug()<<"dbTableSort";
    QSqlQuery* query=new QSqlQuery(*m_db);
    if (!query->exec(u8"SELECT * FROM 数据库表1 ORDER BY 随机数2 DESC")) {
      emit dbQueryError(3,query->lastError().text());

        return;
    }

    // 更新UI表格
    emit clearDBDataTable();

    insertDBDataToTable(1,query);


}

void CMyWorkThread::reserveDBTableSingleRow()
{
   // 打印“随机数3”列为奇数的行
    qDebug()<<"reserveDBTableSingleRow";
    QSqlQuery* query=new QSqlQuery(*m_db);
    if (!query->exec(u8"SELECT * FROM 数据库表1 WHERE 随机数3 % 2 = 1")) {
        emit dbQueryError(4,query->lastError().text());

        return;
    }


    // 更新UI表格
    emit clearDBDataTable();
    //插入操作
    insertDBDataToTable(2,query);

}

void CMyWorkThread::sendStringTask(QString str)
{
    //每隔500毫秒发一次
    qDebug()<<"the sub thread sent str:"<<str;

    emit endSendStringTask();
}
