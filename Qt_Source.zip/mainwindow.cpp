﻿#include "mainwindow.h"
#include "ui_mainwindow.h"
#include<QLabel>
#include<QToolBar>
#include<QTableWidget>
#include<QPushButton>
#include<QHeaderView>
#include<QHBoxLayout>
#include<QTreeWidget>
#include<QStandardItemModel>
#include<QRandomGenerator>
#include<QFileDialog>
#include<QMessageBox>
#include<QThreadPool>
#include<QFile>
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include<QMenuBar>
#include<QStatusBar>
#include <QPluginLoader>
#include<QStandardItemModel>
#include"shorttaskthread.h"
#include"myworkthread.h"
#include"subandpubmessagethread.h"
MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    ,m_workThread(0)
    ,m_file(0)
{

    ui->setupUi(this);
    // 获取当前日期
    QDate currentDate = QDate::currentDate();
    // 格式化为 yyyy-MM-dd字符串格式
    QString formattedDate=u8"界面程序-毛金鹏-";
    formattedDate+= currentDate.toString("yyyy-MM-dd");
    //设置窗口标题
    setWindowTitle(formattedDate);
    m_workThread=new CMyWorkThread;
    m_messageThread=new CSubAndPubMessageThread;
    m_file=new QFile;

    // 按钮点击事件
    connect(ui->WriteFile_Btn, &QPushButton::clicked, this, &MainWindow::startWriteFileTask);

    initDB();

    initTable1();

    initTreeModel();

    initTileBarTools();

    initSendStringEvent();

    m_workThread->start();
    m_messageThread->start();

}

MainWindow::~MainWindow()
{
    if(m_workThread&&m_workThread->isRunning()){
        delete m_workThread;
    }
    if(m_messageThread&&m_messageThread->isRunning()){
        delete m_messageThread;
    }

    if(m_file){
        if(m_file->isOpen())m_file->close();
        delete m_file;
    }

    if(ui)
    delete ui;
}

int MainWindow::insertDBDataToTable(int op,int row,int column,QTableWidgetItem* item)
{
    switch (op) {
    case 0:
    {

        if(ui->MyDBTable->rowCount()<=row)ui->MyDBTable->insertRow(row);
        ui->MyDBTable->setItem(row, column, item);

    }
        break;
    case 1:
    {
        if(ui->MyDBTable->rowCount()<=row)ui->MyDBTable->insertRow(row);
        ui->MyDBTable->setItem(row, column, item);
    }
        break;
    case 2:
    {

        if(ui->MyDBTable->rowCount()<=row)ui->MyDBTable->insertRow(row);
        ui->MyDBTable->setItem(row, column, item);
    }
        break;
    default:
        break;
    }
    return op;
}

void MainWindow::insertBDFinishedCb(int op)
{
    switch (op) {
    case 0:
    {
        QMessageBox::information(this, "成功", "表数据生成并写入完成");
    }
        break;
    case 1:
    {
        QMessageBox::information(this, u8"排序结果", u8"排序完成");
    }
    break;
    case 2:
    {
        QMessageBox::information(this, u8"成功", u8"偶数行数据已删除，奇数行数据已显示在表格中");
    }
    break;

    default:
        break;
    }

}

void MainWindow::TableReverseOrder()
{
// 倒序显示表格内容
for (int i = 0; i < ui->MyTable1->rowCount() / 2; ++i) {
    ui->MyTable1->verticalHeader()->swapSections(i, ui->MyTable1->rowCount() - 1 - i);
}
}
void MainWindow::toolbarOperate1()
{
qDebug()<<"toolbar Operate1 trigger!";
QMessageBox::information(this,"tips","toolbar Operate1 trigger!");
}

void MainWindow::toolbarOperate2()
{
qDebug()<<"toolbar Operate2 trigger!";
QMessageBox::information(this,"tips","toolbar Operate2 trigger!");
}

void MainWindow::toolbarOperate3()
{
qDebug()<<"toolbar Operate3 trigger!";
QMessageBox::information(this,"tips","toolbar Operate3 trigger!");
}

void MainWindow::toolbarOperate4()
{
qDebug()<<"toolbar Operate4 trigger!";
QMessageBox::information(this,"tips","toolbar Operate4 trigger!");
}

void MainWindow::toolbarOperate5()
{
qDebug()<<"toolbar Operate5 trigger!";
QMessageBox::information(this,"tips","toolbar Operate5 trigger!");
}


void MainWindow::openNewPage()
{
// 创建一个新的空白窗口
qDebug()<<"open the new page";
QMainWindow *newWindow = new QMainWindow(this);
newWindow->setWindowTitle(u8"新页面");
newWindow->resize(400, 300);
newWindow->show();
}

void MainWindow::startWriteFileTask()
{
// 弹出文件路径选择界面
    QString dirPath = QFileDialog::getExistingDirectory(this, u8"选择路径", QDir::homePath());
    if (dirPath.isEmpty()) {
        QMessageBox::warning(this, u8"错误", u8"未选择路径");
        return;
    }

    // 创建文件路径
    QString filePath = dirPath + "/hello.txt";
    m_file->setFileName(filePath);
    if (!m_file->open(QIODevice::WriteOnly | QIODevice::Text)) {
        QMessageBox::critical(this, u8"错误", u8"无法打开文件");
        return;
    }

    // 创建任务
    CShortTaskThread *task = new CShortTaskThread;
    //QRunable没有继承QObject不用担心QFile在QT子线程使用报错问题。
    task->setTaskFunction(&MainWindow::writeFileTask,this,m_file);

    // 启动任务，将任务加入Qt线程池执行，完成后自动销毁
    QThreadPool::globalInstance()->start(task);
}

void MainWindow::clearDBDataTable()
{
    // 清空表格内容
    ui->MyDBTable->clearContents();
    ui->MyDBTable->setRowCount(0);

    // 设置表头
    QStringList headers = {u8"序号", "随机数1", "随机数2", "随机数3"};
    ui->MyDBTable->setColumnCount(headers.size());
    ui->MyDBTable->setHorizontalHeaderLabels(headers);
}

void MainWindow::startPubString()
{

    if(ui->SentStringEdit->text().size()<=0){
        ui->SendStringDisplay->setText(u8"发送文字显示区域");
        QMessageBox::information(this,"tips",u8"请输入您要发布的消息");

        return;
    }
    if(m_messageThread->haTaskRunning()){
        qDebug()<<"stop last task!";
        m_messageThread->stopCurTask();
    }
    ui->SendStringDisplay->setText(ui->SentStringEdit->text());

    emit pubStringTask(ui->SentStringEdit->text());


}

void MainWindow::startSubTopic()
{

    if(ui->SentStringEdit->text().size()<=0){
        ui->SendStringDisplay->setText(u8"发送文字显示区域");
        QMessageBox::information(this,"tips",u8"请输入您要订阅的主题");

        return;
    }
    if(m_messageThread->haTaskRunning()){
        qDebug()<<"stop last task!";
        m_messageThread->stopCurTask();
    }
    ui->SendStringDisplay->setText(ui->SentStringEdit->text());

    emit subTopicTask(ui->SentStringEdit->text());
}

void MainWindow::initTreeModel()
{
// 创建模型
    QStandardItemModel *model = new QStandardItemModel(this);
    model->setColumnCount(5); // 5 列
    QStringList headers = {u8"列1", u8"列2", u8"列3", u8"列4", u8"列5"};//表头
    model->setHorizontalHeaderLabels(headers);

    // 填充树形图模型内容
    for (int i = 0; i < 8; ++i) {
        QList<QStandardItem*> rowItems;
        for (int j = 0; j < 5; ++j) {
            int randomValue = QRandomGenerator::global()->bounded(50); // 生成 0-49 的随机数
            QStandardItem *item = new QStandardItem(QString::number(randomValue));
            rowItems.append(item);
        }
        model->appendRow(rowItems);
    }

    ui->MyTreeView1->setModel(model);
    connect(ui->ConditionValueChange_Btn,&QPushButton::clicked,this,&MainWindow::setValueToZero);
    connect(ui->ReserveSingle_Btn,&QPushButton::clicked,this,&MainWindow::reserveSingle);

}

void MainWindow::initTable1()
{
    // 设置表格的行数和列数

    ui->MyTable1->setColumnCount(5); // 设置列数
QStringList headers = {u8"列1", u8"列2", u8"列3", u8"列4", u8"列5"};//表头

ui->MyTable1->setHorizontalHeaderLabels(headers);
// 设置水平滚动条根据需要显示（默认行为）
ui->MyTable1->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);

//ui->MyTable1->setHorizontalHeaderItem也可
// 填充表格内容
for (int i = 0; i < 8; ++i) {
        ui->MyTable1->insertRow(i);
    for (int j = 0; j < 5; ++j) {

        ui->MyTable1->setItem(i, j, new QTableWidgetItem(QString(u8"数据%1").arg(i * 5 + j)));
    }
}

//连接接表格按钮信号
connect(ui->Reverse_Btn, &QPushButton::clicked, this, &MainWindow::TableReverseOrder);
}

void MainWindow::initTileBarTools()
{
// 添加菜单栏 start
QMenuBar *menuBar = this->menuBar();

// 添加“文件”菜单
QMenu *fileMenu = menuBar->addMenu(u8"文件");
//fileMenu->setIcon("");
// 添加“视图”菜单
QMenu *viewMenu = menuBar->addMenu(u8"视图");
QAction *openNewPageAction = viewMenu->addAction(u8"打开新页面");
connect(openNewPageAction, &QAction::triggered, this, &MainWindow::openNewPage);

// 添加“设置”菜单
QMenu *settingsMenu = menuBar->addMenu(u8"设置");

// 添加“帮助”菜单
QMenu *helpMenu = menuBar->addMenu(u8"帮助");
//添加菜单栏 end

// 添加工具栏 start
QToolBar *toolBar = addToolBar(u8"工具栏");

// 添加 5 个工具栏操作选项
QAction *action1 = toolBar->addAction(QIcon(u8":/icons/icon1.png"), u8"操作1");
QAction *action2 = toolBar->addAction(QIcon(u8":/icons/icon2.png"), u8"操作2");
QAction *action3 = toolBar->addAction(QIcon(u8":/icons/icon3.png"), u8"操作3");
QAction *action4 = toolBar->addAction(QIcon(u8":/icons/icon4.png"), u8"操作4");
QAction *action5 = toolBar->addAction(QIcon(u8":/icons/icon5.png"), u8"操作5");

connect(action1, &QAction::triggered, this, &MainWindow::toolbarOperate1);
connect(action2, &QAction::triggered, this, &MainWindow::toolbarOperate2);
connect(action3, &QAction::triggered, this, &MainWindow::toolbarOperate3);
connect(action4, &QAction::triggered, this, &MainWindow::toolbarOperate4);
connect(action5, &QAction::triggered, this, &MainWindow::toolbarOperate5);
// 添加工具栏 end

// 添加状态栏 start
QStatusBar *statusBar = this->statusBar();

// 左侧区域：左对齐
QLabel* leftLabel = new QLabel(u8"左对齐内容");

// 右侧区域：右对齐
QLabel* rightLabel1 = new QLabel(u8"右对齐内容1");
QLabel* rightLabel2 = new QLabel(u8"右对齐内容2");

// 将容器添加到状态栏
statusBar->addWidget(leftLabel); //默认左对齐
statusBar->addPermanentWidget(rightLabel1); // 默认右对齐
statusBar->addPermanentWidget(rightLabel2); // 默认右对齐
// 添加状态栏 end
}

void MainWindow::initDB()
{

// 连接按钮点击事件
connect(ui->CreateDBTableData_Btn, &QPushButton::clicked,m_workThread,&CMyWorkThread::createDBTableData);
connect(ui->DBTableSort_Btn, &QPushButton::clicked,m_workThread,&CMyWorkThread::dbTableSort);
connect(ui->ReserveDBTableSingleRow_Btn, &QPushButton::clicked,m_workThread,&CMyWorkThread::reserveDBTableSingleRow);

connect(this,&MainWindow::initDB_S,m_workThread,&CMyWorkThread::initDB);
connect(m_workThread,&CMyWorkThread::insertDBDataToTable_S,this,&MainWindow::insertDBDataToTable);
connect(m_workThread,&CMyWorkThread::insertBDFinished,this,&MainWindow::insertBDFinishedCb);

connect(m_workThread,&CMyWorkThread::dbQueryError,this,&MainWindow::dbQueryError);

connect(m_workThread,&CMyWorkThread::clearDBDataTable,this,&MainWindow::clearDBDataTable);

emit initDB_S();
}

void MainWindow::initSendStringEvent()
{
    connect(ui->pubTargetMessage_Btn,&QPushButton::clicked,this,&MainWindow::startPubString);
    connect(ui->SubTargetTopic_Btn,&QPushButton::clicked,this,&MainWindow::startSubTopic);
    connect(this,&MainWindow::pubStringTask,m_messageThread,&CSubAndPubMessageThread::pubTheMessage);
    connect(this,&MainWindow::subTopicTask,m_messageThread,&CSubAndPubMessageThread::subTheTopic);
    connect(m_messageThread,&CSubAndPubMessageThread::endPubOrSubTask,this,&MainWindow::endPubOrSubTask);
    connect(m_messageThread, &QThread::started, m_messageThread, &CSubAndPubMessageThread::threadInit);
    ui->SubTargetTopic_Btn->setDisabled(true);
}

int MainWindow::writeFileTask(QFile* file)
{
QTextStream out(file);
out.setEncoding(QStringConverter::Utf8);; // 设置编码为 UTF-8,防止中文乱码

for (int i = 0; i < 100; ++i) {
    out << u8"你好，“文件”\n"; // 写入内容
    out.flush(); // 刷新缓冲区
    qDebug()<<u8"第"<<i+1<<u8"次写入hello.txt文件";
    QThread::msleep(500); // 等待 500ms
}

file->close();
qDebug()<<u8"文件写入完成";
return 1;
}

void MainWindow::endPubOrSubTask(int op)
{
switch (op) {
case 0://发布
qDebug()<<u8"结束发布任务";
    break;
case 1://订阅
    qDebug()<<u8"结束订阅任务";
    break;
default:
    break;
}


}

void MainWindow::setValueToZero()
{
auto model=(QStandardItemModel*)ui->MyTreeView1->model();
for (int i = 0; i < model->rowCount(); ++i) {
    for (int j = 0; j < model->columnCount(); ++j) {

        QStandardItem *item = model->item(i, j);
        int value = item->text().toInt();
        if (value <= 25) {
            item->setText("0");
        }
    }
}
}

void MainWindow::reserveSingle()
{
qDebug()<<"reserveSingle trigger";
auto model=(QStandardItemModel*)ui->MyTreeView1->model();
for (int i = model->rowCount() - 1; i >= 0; --i) {
    if (i % 2 == 0) { // 删除偶数行（索引从 0 开始）
        model->removeRow(i);//只删除
    }
}

}

void MainWindow::dbQueryError(int op,const QString& errorStr)
{
switch (op) {

case 1:
    QMessageBox::critical(this, u8"错误", "无法打开数据库:" + errorStr);
    break;
case 2:
    QMessageBox::critical(this, u8"错误", u8"无法创建表: " + errorStr);
    break;
case 3:
    QMessageBox::critical(this, u8"错误", "排序失败: " + errorStr);
    break;
case 4:
    QMessageBox::critical(this, u8"错误", u8"查询失败: " + errorStr);
    break;
case 5:
    QMessageBox::critical(this, u8"错误", "插入数据失败: " +errorStr);
    break;
case 6:
    QMessageBox::critical(this, "错误", "删除失败: " + errorStr);
    break;
default:
    break;
}
}

