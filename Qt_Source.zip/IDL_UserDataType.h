// Don't modify this file as it will be overwritten.
//
#include "CDR/CDR.h"
#include "ReturnCode.h"
#include "BasicTypes.h"

#ifndef IDL_UserDataType_hh
#define IDL_UserDataType_hh

#ifndef UserDataType_defined
#define UserDataType_defined

struct UserDataType {
  UserDataType()
	{
		nm = 0;
		b = 0;
		str = new char[255];
		str[0]= '\0';
	}

  UserDataType(const UserDataType  &IDL_s);

  ~UserDataType(){
		delete str;
		str = NULL;
	}

  	int StructSize()
	{
		int strSize = 0;
		strSize += sizeof(UserDataType);
		strSize += strlen(str);
		return strSize;
	}
  UserDataType& operator= (const UserDataType &IDL_s);

  void Marshal(CDR *cdr) const;
  void UnMarshal(CDR *cdr);

  short nm;
short b;
char* str;
  
};

typedef sequence<UserDataType> UserDataTypeSeq;

#endif

#ifndef demo_defined
#define demo_defined

struct demo {
  demo()
	{
		nb = 0;
		y = 0;
		str = new char[255];
		str[0]= '\0';
	}

  demo(const demo  &IDL_s);

  ~demo(){
		delete str;
		str = NULL;
	}

  	int StructSize()
	{
		int strSize = 0;
		strSize += sizeof(demo);
		strSize += strlen(str);
		return strSize;
	}
  demo& operator= (const demo &IDL_s);

  void Marshal(CDR *cdr) const;
  void UnMarshal(CDR *cdr);

  short nb;
short y;
char* str;
  
};

typedef sequence<demo> demoSeq;

#endif




#endif /*IDL_UserDataType_hh */
