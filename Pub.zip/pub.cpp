/**********************************************************
*****************发布端程序publisher.cpp********************
***********************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <cstring>
#include <unistd.h>
#include <csignal>
#include <ctime>
#include <iostream>
#include<atomic>
#include <openssl/md5.h>
#include <chrono> 
/* IDL_TypeSupport.h中包含所有依赖的头文件 */
#include "IDL_TypeSupport.h"
//控制执行哪个测试用例
#define WhichExample 1

static void MaoMrMD5(const std::string& input, std::string& output)
{

	std::string result;
	std::string data((const size_t)16, '\0');//128位
	MD5_CTX md5;
	MD5_Init(&md5);
	MD5_Update(&md5, input.c_str(), input.size());
	MD5_Final((unsigned char*)data.c_str(), &md5);
	char temp[3]{};
	for (size_t i = 0; i < data.size(); i++)
	{
		memset(temp, 0, sizeof(temp));
		snprintf(temp, sizeof(temp), "%02x", data[i] & 0xFF);
		result += temp;
	}
	output = result;

}
static int subscriber_shutdown(	DomainParticipant* participant)
{
	ReturnCode_t retcode;
	int status = 0;

	if (participant != NULL) {
		retcode = participant->delete_contained_entities();
		if (retcode != RETCODE_OK) {
			fprintf(stderr, "delete_contained_entities error %d\n", retcode);
			status = -1;
		}

		retcode = DomainParticipantFactory::get_instance()->delete_participant(participant);
		if (retcode != RETCODE_OK) {
			fprintf(stderr, "delete_participant error %d\n", retcode);
			status = -1;
		}
	}
	return status;
}

/* 删除所有实体 */
static int publisher_shutdown(DomainParticipant *participant)
{
	ReturnCode_t retcode; 
	int status = 0;

	if (participant != NULL) {
		retcode = participant->delete_contained_entities();
		if (retcode != RETCODE_OK) {
			fprintf(stderr, "delete_contained_entities error %d\n", retcode);
			status = -1;
		}

		retcode = DomainParticipantFactory::get_instance()->delete_participant(participant);
		if (retcode != RETCODE_OK) {
			fprintf(stderr, "delete_participant error %d\n", retcode);
			status = -1;
		}
	}

	return status;
}
struct SenderData
{
	~SenderData();
	DomainParticipant* participant = NULL;
	Publisher* publisher = NULL;
	Topic* topic = NULL;
	DataWriter* writer = NULL;
	UserDataTypeDataWriter* UserDataType_writer = NULL;
	UserDataType* instance = NULL;
	ReturnCode_t retcode;
	InstanceHandle_t instance_handle = HANDLE_NIL;
	const char* type_name = NULL;
	void StartTimer(int interval);//单位秒
	void StopTimer();
	// 获取当前时间戳（微秒）
	static long long getCurrentTimestamp();
	// 定时器回调函数
	static void timerHandler(int signum);
	static long long m_TimerDuration;//秒
	static std::atomic<long long> m_SentPacketCount;
	static std::atomic<long long> m_TotalDataSize;//bit
	timer_t m_TimerId;
	string m_MD5Str;
	static std::atomic<long long> m_StartTime;
	static std::atomic<long long> m_EndTime;
	static std::atomic<long long> m_CircleCount;
	static long long m_LimitCircleCount;
};
class UserDataTypeListener : public DataReaderListener {
public:
	UserDataTypeListener()
	{
		
	};
	virtual void on_data_available(DataReader* reader);
	
	//发送数据者创建
	SenderData m_SenderData;
};
long long SenderData::m_TimerDuration = 0;
std::atomic<long long> SenderData::m_TotalDataSize(0);
std::atomic<long long> SenderData::m_SentPacketCount(0);
std::atomic<long long> SenderData::m_StartTime(0);
std::atomic<long long> SenderData::m_EndTime(0);
std::atomic<long long> SenderData::m_CircleCount(0);
long long SenderData::m_LimitCircleCount = 0;
SenderData::~SenderData()
{
	

	StopTimer();
}

/* 重写继承过来的方法on_data_available()，在其中进行数据监听读取操作 */
void UserDataTypeListener::on_data_available(DataReader* reader)
{
	UserDataTypeDataReader* UserDataType_reader = NULL;
	UserDataTypeSeq data_seq;
	SampleInfoSeq info_seq;
	ReturnCode_t retcode;
	int i;

	/* 利用reader，创建一个读取UserDataType类型的UserDataType_reader*/
	UserDataType_reader = UserDataTypeDataReader::narrow(reader);
	if (UserDataType_reader == NULL) {
		fprintf(stderr, "DataReader narrow error\n");
		return;
	}

	/* 获取数据，存放至data_seq，data_seq是一个队列 */
	retcode = UserDataType_reader->read(
		data_seq, info_seq, 10, 0, 0, 0);

	if (retcode == RETCODE_NO_DATA) {
		return;
	}
	else if (retcode != RETCODE_OK) {
		fprintf(stderr, "take error %d\n", retcode);
		return;
	}
	SenderData::m_EndTime.store(SenderData::getCurrentTimestamp());
	SenderData::m_CircleCount.fetch_add(1);
	

	/* 打印数据 */
/* 建议1：避免在此进行复杂数据处理 */
/* 建议2：将数据传送到其他数据处理线程中进行处理 *
/* 建议3：假如数据结构中有string类型，用完后需手动释放 */
	for (i = 0; i < data_seq.length(); ++i) {
		UserDataTypeTypeSupport::print_data(&data_seq[i]);

		if (SenderData::m_CircleCount.load() > m_SenderData.m_LimitCircleCount)break;//到达限定循环次数后停止发送

		m_SenderData.instance->b = (SenderData::m_SentPacketCount.load() + 1) / 65535;
		m_SenderData.instance->nm = (SenderData::m_SentPacketCount.load() + 1) % 65535;
		
		retcode = m_SenderData.UserDataType_writer->write(*(m_SenderData.instance), m_SenderData.instance_handle);
		if (retcode != RETCODE_OK) {
			fprintf(stderr, "write error %d\n", retcode);
		}
		else {
			fprintf(stderr, "%d : write  successfully . .\n", SenderData::m_CircleCount.load());
			
			SenderData::m_SentPacketCount.fetch_add(1);
		}
		
	}


}
void SenderData::StartTimer(int interval)
{
	// 注册信号处理函数
	struct sigaction sa {};
	sa.sa_handler = &SenderData::timerHandler;
	sigaction(SIGALRM, &sa, nullptr);
	std::cout << " StartTimer !" << std::endl;
	// 创建定时器

	struct sigevent sev {};
	sev.sigev_notify = SIGEV_SIGNAL;
	sev.sigev_signo = SIGALRM;
	sev.sigev_value.sival_ptr = &m_TimerId;
	if (timer_create(CLOCK_REALTIME, &sev, &m_TimerId) == -1) {
		std::cerr << "Failed to create timer!" << std::endl;
		return;
	}

	// 设置定时器间隔
	struct itimerspec its {};
	its.it_value.tv_sec = 1;  // 第一次触发时间（1 秒后）
	its.it_value.tv_nsec = 0;
	its.it_interval.tv_sec = interval;  // 后续触发间隔（1 秒）
	its.it_interval.tv_nsec = 0;
	if (timer_settime(m_TimerId, 0, &its, nullptr) == -1) {
		std::cerr << "Failed to set timer!" << std::endl;
		return;
	}

}

void SenderData::StopTimer()
{
	// 删除定时器
	timer_delete(m_TimerId);
	m_TimerDuration = 0;
	m_TotalDataSize = 0;
	m_SentPacketCount = 0;
	m_StartTime = 0;
	m_EndTime = 0;
}

long long SenderData::getCurrentTimestamp()
{
	auto now = std::chrono::system_clock::now();  // 获取当前时间点
	auto duration = now.time_since_epoch();  // 获取时间间隔
	return std::chrono::duration_cast<std::chrono::microseconds>(duration).count();
}

void SenderData::timerHandler(int signum)
{
	//std::cout << "TimerHandler trigger!" << std::endl;
	if (WhichExample == 2) {
		m_TimerDuration++;
		auto ret = m_SentPacketCount.load() / m_TimerDuration;

		//吞吐量
		std::cout << "The Throughput :" << ret << "Mbps" << std::endl;
		
		

	}
	else if (WhichExample == 3) {
		if (m_CircleCount.load() != 0) {
			auto ret = (m_EndTime.load() - m_StartTime.load()) / m_CircleCount.load() / 2;
			//延迟
			std::cout << "The Delay :" << ret << " us" << std::endl;
		}
		
	}

}


static int initRecver(DomainParticipant* &participant, Topic* topic, UserDataTypeListener* &reader_listener,const SenderData& senderdata) {
	//DomainParticipant* participant = NULL;
	Subscriber* subscriber = NULL;
	//Topic* topic = NULL;
	//UserDataTypeListener* reader_listener = NULL;
	DataReader* reader = NULL;
	ReturnCode_t retcode;
	const char* type_name = NULL;
	int count = 0;
	int status = 0;

	/* 1. 创建一个participant，可以在此处定制participant的QoS */
	/* 建议1：在程序启动后优先创建participant，进行资源初始化*/
	/* 建议2：相同的domainId只创建一次participant，重复创建会占用大量资源 */
	participant = DomainParticipantFactory::get_instance()->create_participant(
		1, PARTICIPANT_QOS_DEFAULT/* participant默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (participant == NULL) {
		fprintf(stderr, "create_participant error\n");
		subscriber_shutdown(participant);
		participant = NULL;
		return -1;
	}

	/* 2. 创建一个subscriber，可以在创建subscriber的同时定制其QoS  */
	/* 建议1：在程序启动后优先创建subscriber*/
	/* 建议2：一个participant下创建一个subscriber即可，无需重复创建 */
	subscriber = participant->create_subscriber(
		SUBSCRIBER_QOS_DEFAULT/* 默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (subscriber == NULL) {
		fprintf(stderr, "create_subscriber error\n");
		subscriber_shutdown(participant);
		participant = NULL;
		return -1;
	}

	/* 3. 在创建主题之前注册数据类型 */
	/* 建议1：在程序启动后优先进行注册 */
	/* 建议2：一个数据类型注册一次即可 */
	type_name = UserDataTypeTypeSupport::get_type_name();
	retcode = UserDataTypeTypeSupport::register_type(
		participant, type_name);
	if (retcode != RETCODE_OK) {
		fprintf(stderr, "register_type error %d\n", retcode);
		subscriber_shutdown(participant);
		participant = NULL;
		return -1;
	}

	/* 4. 创建主题，并定制主题的QoS  */
	/* 建议1：在程序启动后优先创建Topic */
	/* 建议2：一种主题名创建一次即可，无需重复创建 */
	topic = participant->create_topic(
		"Example UserDataType1"/* 主题名，应与发布者主题名一致 */,
		type_name, TOPIC_QOS_DEFAULT/* 默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (topic == NULL) {
		fprintf(stderr, "create_topic error1\n");
		subscriber_shutdown(participant);
		participant = NULL;
		return -1;
	}

	/* 5. 创建一个监听器 */
	reader_listener = new UserDataTypeListener();

	reader_listener->m_SenderData = senderdata;
	/* 6. 创建datareader，并定制datareader的QoS */
	/* 建议1：在程序启动后优先创建datareader*/
	/* 建议2：创建一次即可，无需重复创建 */
	/* 建议3：在程序退出时再进行释放 */
	/* 建议4：避免打算接收数据时创建datareader，接收数据后删除，该做法消耗资源，影响性能 */
	reader = subscriber->create_datareader(
		topic, DATAREADER_QOS_DEFAULT/* 默认QoS */,
		reader_listener/* listener */, STATUS_MASK_ALL);
	if (reader == NULL) {
		fprintf(stderr, "create_datareader error\n");
		subscriber_shutdown(participant);
		participant = NULL;
		delete reader_listener;
		reader_listener = NULL;
		return -1;
	}

}

/* 发布者函数 */
extern "C" int publisher_main(int domainId, int sample_count,const string& str)
{
	DomainParticipant *participant = NULL;
	Publisher *publisher = NULL;
	Topic *topic = NULL;
	DataWriter *writer = NULL;
	UserDataTypeDataWriter * UserDataType_writer = NULL;
	UserDataType *instance = NULL;
	ReturnCode_t retcode;
	InstanceHandle_t instance_handle = HANDLE_NIL;
	const char *type_name = NULL;
	int count = 0;

	/* 1. 创建一个participant，可以在此处定制participant的QoS */
	/* 建议1：在程序启动后优先创建participant，进行资源初始化*/
	/* 建议2：相同的domainId只创建一次participant，重复创建会占用大量资源 */ 
	participant = DomainParticipantFactory::get_instance()->create_participant(
		domainId, PARTICIPANT_QOS_DEFAULT/* participant默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (participant == NULL) {
		fprintf(stderr, "create_participant error\n");
		publisher_shutdown(participant);
		return -1;
	}


	/* 2. 创建一个publisher，可以在创建publisher的同时定制其QoS  */
	/* 建议1：在程序启动后优先创建publisher */
	/* 建议2：一个participant下创建一个publisher即可，无需重复创建 */
	publisher = participant->create_publisher(
		PUBLISHER_QOS_DEFAULT /* 默认QoS */, 
		NULL /* listener */, STATUS_MASK_NONE);
	if (publisher == NULL) {
		fprintf(stderr, "create_publisher error\n");
		publisher_shutdown(participant);
		return -1;
	}

	/* 3. 在创建主题之前注册数据类型 */
	/* 建议1：在程序启动后优先进行注册 */
	/* 建议2：一个数据类型注册一次即可 */
	type_name = UserDataTypeTypeSupport::get_type_name();
	retcode = UserDataTypeTypeSupport::register_type(
		participant, type_name);
	if (retcode != RETCODE_OK) {
		fprintf(stderr, "register_type error %d\n", retcode);
		publisher_shutdown(participant);
		return -1;
	}

	/* 4. 创建主题，并定制主题的QoS  */
	/* 建议1：在程序启动后优先创建Topic */
	/* 建议2：一种主题名创建一次即可，无需重复创建 */
	topic = participant->create_topic(
		"Example UserDataType"/* 主题名 */,
		type_name /* 类型名 */, TOPIC_QOS_DEFAULT/* 默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (topic == NULL) {
		fprintf(stderr, "create_topic error\n");
		publisher_shutdown(participant);
		return -1;
	}
	
	
	/* 5. 创建datawriter，并定制datawriter的QoS  */
	/* 建议1：在程序启动后优先创建datawriter */
	/* 建议2：创建一次即可，无需重复创建 */
	/* 建议3：在程序退出时再进行释放 */
	/* 建议4：避免打算发送数据时创建datawriter，发送数据后删除，该做法消耗资源，影响性能 */
	writer = publisher->create_datawriter(
		topic , DATAWRITER_QOS_DEFAULT/* 默认QoS */,
		NULL /* listener */, STATUS_MASK_NONE);
	if (writer == NULL) {
		fprintf(stderr, "create_datawriter error\n");
		publisher_shutdown(participant);
		return -1;
	}
	UserDataType_writer = UserDataTypeDataWriter::narrow(writer);
	if (UserDataType_writer == NULL) {
		fprintf(stderr, "DataWriter narrow error\n");
		publisher_shutdown(participant);
		return -1;
	}
	
	/* 6. 创建一个数据样本 */
	/* 建议：该数据为new出来的，使用后用户需要调用delete_data进行释放内存*/
	instance = UserDataTypeTypeSupport::create_data();
	if (instance == NULL) {
		fprintf(stderr, "UserDataTypeTypeSupport::create_data error\n");
		publisher_shutdown(participant);
		return -1;
	}
	instance->str = (char*)str.c_str();
	SenderData sdata{};
	sdata.StartTimer(1);
	if (WhichExample == 3) {
		//初始化接收者
		
		sdata.instance = instance;
		sdata.instance_handle = instance_handle;
		sdata.participant = participant;
		sdata.publisher = publisher;
		sdata.retcode = retcode;
		sdata.topic = topic;
		sdata.type_name = type_name;
		sdata.UserDataType_writer = UserDataType_writer;
		sdata.writer = writer;
		sdata.m_LimitCircleCount = sample_count;//限制总共循环次数
		UserDataTypeListener* reader_listener = NULL;
		DomainParticipant* recvParticipant = NULL;
		initRecver(/*participant*/recvParticipant, topic, reader_listener, sdata);
		//先主动发送一次
		retcode = UserDataType_writer->write(*instance, instance_handle);
		if (retcode != RETCODE_OK) {
			fprintf(stderr, "write error %d\n", retcode);
		}
		else {
			fprintf(stderr, "%d : write  successfully . . \n", SenderData::m_CircleCount.load());
			SenderData::m_StartTime.store(SenderData::getCurrentTimestamp());
		}

		while (SenderData::m_CircleCount.load() < sample_count) {
			//主线程阻塞或者等待到达循环次数
		}

		/* 8. 删除所有接收的实体和监听器 */
		if(recvParticipant)
		subscriber_shutdown(recvParticipant);
		if(reader_listener)
		delete reader_listener;

	}
	else {
		
		/* 7. 主循环 ，发送数据 */
		for (count = 0; (sample_count == 0) || (count < sample_count); ++count) {
			//让接受方知道发送方共发送了多少包
			instance->b= (SenderData::m_SentPacketCount.load() + 1)/65535;
			instance->nm = (SenderData::m_SentPacketCount.load() + 1) % 65535;

			retcode = UserDataType_writer->write(*instance, instance_handle);
			if (retcode != RETCODE_OK) {
				fprintf(stderr, "write error %d\n", retcode);
			}
			else {
				if (WhichExample != 2)fprintf(stderr, "%d : write  successfully . . \n", count);
				SenderData::m_TotalDataSize.store((instance->StructSize() - sizeof(char*)) * 8);
				SenderData::m_SentPacketCount.fetch_add(1);
				//std::cout << "The Sent packet count :" << SenderData::m_SentPacketCount.load() << std::endl;
			}
			if (WhichExample == 1)sleep(1);//沉睡1秒
		}
	}

	/* 8. 删除数据样本 */
	retcode = UserDataTypeTypeSupport::delete_data(instance);
	if (retcode != RETCODE_OK) {
		fprintf(stderr, "UserDataTypeTypeSupport::delete_data error %d\n", retcode);
	}

	/* 9. 删除所有实例 */
	return publisher_shutdown(participant);
}

int main(int argc, char *argv[])
{
	int domain_id = 0;
	int sample_count = 0; /* 无限循环 */
	string str;
	if (argc >= 2) {
		domain_id = atoi(argv[1]);  /* 发送至域domain_id */
	}
	if (argc >= 3) {
		sample_count = atoi(argv[2]); /* 发送sample_count次 */
	}
	if (argc >= 4) {
		str = argv[3];
		if (WhichExample == 1) {
			string MD5;
			MaoMrMD5(str, MD5);
			str += MD5;
		}
	}
	else {
		std::cout << "please assign the message string to send on the third command-line argument position!"<<std::endl;
		return 1;
	}
	return publisher_main(domain_id, sample_count,str);
}
